//Title: Sci-Fi Name Generator
//Names: Anthony Cooper & Madjenskey Philippe
//Date Submitted: 10/22/22
///////////////////////////////////////////////////////////////////////////////////////
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    //Write your whole program here!
    //This area gathers the users information
    Scanner input = new Scanner(System.in);
    System.out.println("If you provide me some information I will provide a science fiction name for you.\nPlease have all responses be at least three characters long.");
    System.out.println("Enter your first name: ");
    String first_name = input.nextLine();
    System.out.println("Enter your last name: ");
    String last_name = input.nextLine();
    System.out.println("Enter the city where you or one of your parents were born: ");
    String city = input.nextLine();
    System.out.println("Enter the name of your grammar school: ");
    String grammer_school = input.nextLine();
    System.out.println("Enter the first name of a sibling or other relative: ");
    String relative = input.nextLine();
    System.out.println("Enter the first name of a second sibling or other relative: ");
    String relativeSecond = input.nextLine();

   //////////////////////////////////////////////////////////////////////////////////////////
    //This area creates the first name
    String firstThree = first_name.substring(0,3); //gets first 3 letters of first name
    String LastThree = last_name.substring(0,2); //gets first 2 letters of last name
    String firstLetter = firstThree.substring(0,1); //gets the first letter of first name
    String rest = firstThree.substring(1,3); //stores the rest of the first three letters of the first name other than the first letter
    
    String SciFirstName = firstLetter.toUpperCase() + rest.toLowerCase() + LastThree.toLowerCase(); //turns the first letter of the first name to upper case, the rest of the first three letters of the first name to lower case, and the first three letters of the last name to lowercase and combines them all together

  ///////////////////////////////////////////////////////////////////////////////////////////
    //This area creates the last name
    String FirstTwoCity = city.substring(0,2); //gets the first two letters of the city name
    String LastThreeSchool = grammer_school.substring(grammer_school.length()-3,grammer_school.length()); //gets the last three letters of the school name
    String firstletter2 = FirstTwoCity.substring(0,1); //gets the first letter of the city name
    String rest2 = FirstTwoCity.substring(1,2); //gets the second letter of the city name
    
    String SciLastName = firstletter2.toUpperCase() + rest2.toLowerCase() + LastThreeSchool.toLowerCase(); //turns the first letter of the city name to upper case, the second letter of the city name to lower case, and the last three letters of the school name to lowercase and combines them all together

///////////////////////////////////////////////////////////////////////////////////////////

    //This area creates the place of origin
    int rand1 = ((int)(Math.random()*(relative.length()-1)) + 1); //random number between 1 and length of first relative - 1
    int rand2 = ((int)(Math.random()*(relativeSecond.length()-1)) + 1); //same thing with second relative
    String LastLetters1 = relative.substring(rand1,relative.length()); //gets the characters in the first relative between rand1 and the last letter
    String LastLetters2 = relativeSecond.substring(rand2,relativeSecond.length()); //same thing with second relative
    String firstLetter3 = LastLetters1.substring(0,1); //gets the first letter of the first relative's substring
    String rest3 = LastLetters1.substring(1,LastLetters1.length()); //stores the rest of the first relative's substring
    String placeOfOrigin = firstLetter3.toUpperCase() + rest3.toLowerCase() + LastLetters2.toLowerCase(); //turns the first letter of the first relatives substring to uppercase, the rest of the first relatives substring to lowercase, and the second relatives substring to lowercase and combines them all together
    ///////////////////////////////////////////////////////////////////////////////////
    System.out.println("Hello "+ SciFirstName+" "+SciLastName+" of "+ placeOfOrigin + ".");
//prints out the final message
    }
  } 